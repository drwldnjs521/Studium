/*
 * Diese Funktion soll die Strings "string1" und "string2" hintereinander
 * in den String "zusammen" schreiben.
 * Sie dürfen annehmen, dass in "zusammen" ausreichend Platz ist.
 */

void strings_verbinden(char zusammen[], char string1[], char string2[]);
