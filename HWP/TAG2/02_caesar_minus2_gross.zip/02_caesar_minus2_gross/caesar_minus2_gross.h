
void caesar(char *klartext);

int encode_and_compare(char *clearstring, char *string_to_encode);
